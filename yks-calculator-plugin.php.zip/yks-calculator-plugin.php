<?php
/*
Plugin Name: YKS Hesaplayıcı
Plugin URI: http://example.com/yks-hesaplayici
Description: YKS sınavları için hedef ve sonuç kaydetme eklentisi
Version: 1.0
Author: Your Name
Author URI: http://example.com
*/

// Eklenti aktive edildiğinde çalışacak fonksiyon
function yks_hesaplayici_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // Hedefler tablosu için SQL
    $table_name = $wpdb->prefix . 'yks_targets';
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        tyt_turkce_dogru int(11) NOT NULL,
        tyt_turkce_yanlis int(11) NOT NULL,
        tyt_sosyal_b_dogru int(11) NOT NULL,
        tyt_sosyal_b_yanlis int(11) NOT NULL,
        tyt_t_matematik_dogru int(11) NOT NULL,
        tyt_t_matematik_yanlis int(11) NOT NULL,
        tyt_fen_b_dogru int(11) NOT NULL,
        tyt_fen_b_yanlis int(11) NOT NULL,
        ayt_matematik_dogru int(11) NOT NULL,
        ayt_matematik_yanlis int(11) NOT NULL,
        ayt_fizik_dogru int(11) NOT NULL,
        ayt_fizik_yanlis int(11) NOT NULL,
        ayt_kimya_dogru int(11) NOT NULL,
        ayt_kimya_yanlis int(11) NOT NULL,
        ayt_biyoloji_dogru int(11) NOT NULL,
        ayt_biyoloji_yanlis int(11) NOT NULL,
        ayt_turk_dili_ve_edebiyati_dogru int(11) NOT NULL,
        ayt_turk_dili_ve_edebiyati_yanlis int(11) NOT NULL,
        ayt_tarih1_dogru int(11) NOT NULL,
        ayt_tarih1_yanlis int(11) NOT NULL,
        ayt_cografya1_dogru int(11) NOT NULL,
        ayt_cografya1_yanlis int(11) NOT NULL,
        ayt_tarih2_dogru int(11) NOT NULL,
        ayt_tarih2_yanlis int(11) NOT NULL,
        ayt_cografya2_dogru int(11) NOT NULL,
        ayt_cografya2_yanlis int(11) NOT NULL,
        ayt_felsefe_grubu_dogru int(11) NOT NULL,
        ayt_felsefe_grubu_yanlis int(11) NOT NULL,
        ayt_dkab_dogru int(11) NOT NULL,
        ayt_dkab_yanlis int(11) NOT NULL,
        ydt_dogru int(11) NOT NULL,
        ydt_yanlis int(11) NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";

    // Sınavlar tablosu için SQL
    $table_name = $wpdb->prefix . 'yks_exams';
    $sql .= "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        exam_name varchar(255) NOT NULL,
        exam_date date NOT NULL,
        tyt_turkce_dogru int(11) NOT NULL,
        tyt_turkce_yanlis int(11) NOT NULL,
        tyt_sosyal_b_dogru int(11) NOT NULL,
        tyt_sosyal_b_yanlis int(11) NOT NULL,
        tyt_t_matematik_dogru int(11) NOT NULL,
        tyt_t_matematik_yanlis int(11) NOT NULL,
        tyt_fen_b_dogru int(11) NOT NULL,
        tyt_fen_b_yanlis int(11) NOT NULL,
        ayt_matematik_dogru int(11) NOT NULL,
        ayt_matematik_yanlis int(11) NOT NULL,
        ayt_fizik_dogru int(11) NOT NULL,
        ayt_fizik_yanlis int(11) NOT NULL,
        ayt_kimya_dogru int(11) NOT NULL,
        ayt_kimya_yanlis int(11) NOT NULL,
        ayt_biyoloji_dogru int(11) NOT NULL,
        ayt_biyoloji_yanlis int(11) NOT NULL,
        ayt_turk_dili_ve_edebiyati_dogru int(11) NOT NULL,
        ayt_turk_dili_ve_edebiyati_yanlis int(11) NOT NULL,
        ayt_tarih1_dogru int(11) NOT NULL,
        ayt_tarih1_yanlis int(11) NOT NULL,
        ayt_cografya1_dogru int(11) NOT NULL,
        ayt_cografya1_yanlis int(11) NOT NULL,
        ayt_tarih2_dogru int(11) NOT NULL,
        ayt_tarih2_yanlis int(11) NOT NULL,
        ayt_cografya2_dogru int(11) NOT NULL,
        ayt_cografya2_yanlis int(11) NOT NULL,
        ayt_felsefe_grubu_dogru int(11) NOT NULL,
        ayt_felsefe_grubu_yanlis int(11) NOT NULL,
        ayt_dkab_dogru int(11) NOT NULL,
        ayt_dkab_yanlis int(11) NOT NULL,
        ydt_dogru int(11) NOT NULL,
        ydt_yanlis int(11) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Eklenti deaktive edildiğinde çalışacak fonksiyon
function yks_hesaplayici_deactivate() {
    global $wpdb;
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}yks_targets");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}yks_exams");
}

// Eklenti aktivasyon ve deaktivasyon kancaları
register_activation_hook(__FILE__, 'yks_hesaplayici_activate');
register_deactivation_hook(__FILE__, 'yks_hesaplayici_deactivate');

?>
